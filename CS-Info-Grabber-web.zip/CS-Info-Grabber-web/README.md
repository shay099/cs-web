# CS-Info-Grabber
Grab details from stripe checkout link


Install google chrome

Install dependencies:

> npm install puppeteer

> npm install pm2

> npm install express

Usage :

> pm2 start main.js

Limitations: 
Only one known issue, You need to convert '#' in the url to %023 or the app will not work properly

Please use pm2 as app might crash!
